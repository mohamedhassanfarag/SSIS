  Truncate table dim_audit
  Truncate table err_destination_output
  Truncate table err_source_output
  Truncate table fact_transactions